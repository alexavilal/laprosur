﻿using System;
using System.Windows.Forms;

namespace SIGA.Windows.Logistica.Formularios.Busquedas.Mantenimientos
{
    public partial class frmRegistroRequerimiento : Form
    {
        public frmRegistroRequerimiento()
        {
            InitializeComponent();
        }

        private void frmRegistroRequerimiento_Load(object sender, EventArgs e)
        {

        }
    }
}
