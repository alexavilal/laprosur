﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SIGA.Windows.Logistica.Secciones
{
    public partial class frmMantenimientoSecciones : Form
    {
        public frmMantenimientoSecciones()
        {
            InitializeComponent();
        }
    }
}
