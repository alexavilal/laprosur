﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SIGA.Windows.Caja
{
    public partial class frmMantenimientoRecibos : Form
    {
        public frmMantenimientoRecibos()
        {
            InitializeComponent();
        }
    }
}
