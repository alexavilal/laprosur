﻿using System;


namespace SIGA.Entities.Logistica
{
    public class TipoDocumentoIdentificacion
    {
        public Int16 CodTipoDocumento { get; set; }
        public string DesDocumento { get; set; }
    }
}
