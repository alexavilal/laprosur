﻿using System;

namespace SIGA.Entities.Logistica
{
    public class TipoDocumento
    {

        public Int16 CodTipoDocumento { get; set; }
        public string DesDocumento { get; set; }
    }
}
