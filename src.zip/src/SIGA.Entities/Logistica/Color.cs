﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SIGA.Entities.Logistica
{
    public class Color
    {

        public Int16 CodColor { get; set; }
        public string DesColor { get; set; }

    }
}
