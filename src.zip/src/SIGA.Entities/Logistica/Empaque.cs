﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SIGA.Entities.Logistica
{
    public class Empaque
    {

        public Int16 CodEmpaque { get; set; }
        public string DesEmpaque { get; set; }
    }
}
