﻿using System;

namespace SIGA.Entities.Logistica
{
    public class Marca
    {

        public Int16 CodMarca { get; set; }
        public string DesMarca { get; set; }
        public string Estado { get; set; }
        public Int16 UsuCreCodigo { get; set; }

    }
}
