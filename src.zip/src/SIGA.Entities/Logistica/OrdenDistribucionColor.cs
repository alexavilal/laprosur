﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SIGA.Entities.Logistica
{
    public class OrdenDistribucionColor
    {

        public int CodigoGeneral { get; set; }
        public Int16 CodigoColor { get; set; }
        public string Color { get; set; }
        public string Alm1 { get; set; }
        public string Alm2 { get; set; }
        public string Alm3 { get; set; }
        public string Alm4 { get; set; }
        public string Alm5 { get; set; }
        public string Alm6 { get; set; }
        public string Alm7 { get; set; }
        public string Alm8 { get; set; }
        public string Alm9 { get; set; }
        public string Alm10 { get; set; }
        public string TotalAlmacen { get; set; }

    }
}
