﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SIGA.Entities.Logistica
{
    public class Capacidad
    {
        public Int16 CodCapacidad { get; set; }
        public string DesCapacidad { get; set; }
    }


}
