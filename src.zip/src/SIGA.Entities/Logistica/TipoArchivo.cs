﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SIGA.Entities.Logistica
{
   public  class TipoArchivo
    {
       public Int16 CodigoTipo { get; set; }
       public string DescripcionTipo { get; set; }

    }
}
