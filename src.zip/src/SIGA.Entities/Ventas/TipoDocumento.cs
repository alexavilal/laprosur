﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SIGA.Entities
{
    public class TipoDocumento
    {
        public byte Codigo { get; set; }
        public string Descripcion { get; set; }
    
    }
}
