﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SIGA.Entities.Ventas
{
    public class TipoCambioResponse
    {
        public string Fecha { get; set; }
        public decimal MonTipoCambio { get; set; }
    }
}
