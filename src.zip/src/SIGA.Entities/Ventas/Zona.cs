﻿

namespace SIGA.Entities.Ventas
{
    public class Zona
    {
        public int IdZona { get; set; }
        public string Descripcion { get; set; }

        public string Estado { get; set; }

        public int Usuario { get; set; }



    }
}
