﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SIGA.Entities.Ventas
{
    public class ParametroResponse
    {
        public int CodParametro { get; set; }
        public string DesParametro { get; set; }
        public string ValParametro1 { get; set; }
        public string ValParametro2 { get; set; }
        public string ValParametro3 { get; set; }
        public string ValParametro4 { get; set; }
    }
}
