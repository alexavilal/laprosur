﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SIGA.Entities.Ventas
{
    public class SubTipoCliente
    {
        public short CodSubTipo { get; set; }
        public string DesSubTipo { get; set; }
    }
}
