﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SIGA.Entities.Ventas
{
    public class TipoCliente
    {
        public short CodTipoCliente { get; set; }
        public string DesTipoCliente { get; set; }
    }
}
