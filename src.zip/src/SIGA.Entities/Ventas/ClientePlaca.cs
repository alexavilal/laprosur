﻿namespace SIGA.Entities.Ventas
{
    public class ClientePlaca : ClienteResponse
    {
        public string PlacaAuto { get; set; }
        public int CodigoRegistro { get; set; }

    }
}
