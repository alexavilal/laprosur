﻿
namespace SIGA.Entities.Administrador
{
    public class Cargo
    {
        public int Codigo { get; set; }
        public string Descripcion { get; set; }
        public string Estado { get; set; }

    }
}
