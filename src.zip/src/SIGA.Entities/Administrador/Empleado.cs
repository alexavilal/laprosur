﻿namespace SIGA.Entities.Administrador
{

    public class Empleado
    {

        public int CodigoEmpleado { get; set; }
        public string ApellidoPaternoEmpleado { get; set; }
        public string ApellidoMaternoEmpleado { get; set; }
        public string NombreEmpleado { get; set; }
        public int CodigoCargo { get; set; }
        public int CodigoTipoDocumento { get; set; }
        public string NumeroDocumento { get; set; }
        public string Estado { get; set; }



    }

}
