﻿using System;

namespace SIGA.Entities.Comunes
{
    public class Base
    {
        public int Codigo { get; set; }
        public Int16 CodigoShort { get; set; }
        public string Descripcion { get; set; }
        public string CodigoString { get; set; }

    }
}
