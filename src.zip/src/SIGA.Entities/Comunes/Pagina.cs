﻿namespace SIGA.Entities.Comunes
{
    public class Pagina
    {
        public string sidx { get; set; }
        public string sord { get; set; }
        public int page { get; set; }
        public int rows { get; set; }
    }
}
