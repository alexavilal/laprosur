﻿namespace SIGA.Entities.Comunes
{
    public class ParametroDtoResponse
    {
        public string Codigo { get; set; }
        public string Descripcion { get; set; }
    }
}
