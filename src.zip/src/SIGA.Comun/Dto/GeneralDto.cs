﻿namespace SIGA.Comun.Dto
{
    public class GeneralDto
    {
        public int Codigo { get; set; }
        public string Empresa { get; set; }
        public string CodigoExterno { get; set; }
        public string CodigoBarra { get; set; }
        public string Marca { get; set; }
        public string Descripcion { get; set; }
        public string Estado { get; set; }
    }
}
