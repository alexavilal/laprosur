﻿namespace SIGA.Business.Comunes
{
    public class ParametroFEBusiness
    {
        //public ParametroResponse BuscarPorCodigo(Int16 pCodigo)
        //{
        //    ParametrosFEDao _ParametroRepository = new ParametrosFEDao();
        //    var lstResult = _ParametroRepository.BuscarPorCodigo(pCodigo);
        //    return lstResult;
        //}
    }
}
