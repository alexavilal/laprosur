﻿namespace SIGA.Business.Comunes
{
    public class ParametroBusiness
    {
        //public ParametroResponse BuscarPorCodigo(Int16 pCodigo)
        //{
        //    ParametroDao _ParametroRepository = new ParametroDao();
        //    var lstResult = _ParametroRepository.BuscarPorCodigo(pCodigo);
        //    return lstResult;
        //}

    }
}
