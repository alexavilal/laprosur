﻿namespace SIGA.Business.Comunes
{
    public class StockBusiness
    {

        //public List<StockArticuloAlmacen> BuscarPorCodigo(int pCodigo)
        //{
        //    StockDao _StockRepository = new StockDao();
        //    var lstResult = _StockRepository.BuscarStockPorSede(pCodigo);
        //    return lstResult;
        //}



    }
}
