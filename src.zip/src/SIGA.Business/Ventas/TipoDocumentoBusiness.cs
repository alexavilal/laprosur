﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SIGA.Business.Ventas
{
    public class TipoDocumentoBusiness
    {
    
       public string ConsultarDatos()
          
       {

           return "hola";
       
       }
    }
}
